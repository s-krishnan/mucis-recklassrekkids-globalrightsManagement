﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RecklassRekkids.GlblRightsMgmt.ServiceEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class Artist:BaseEntity
    {
       


    }
}
