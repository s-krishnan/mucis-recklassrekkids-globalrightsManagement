﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RecklassRekkids.GlblRightsMgmt.ServiceEntities
{
    abstract public class BaseEntity
    {

    }
}
